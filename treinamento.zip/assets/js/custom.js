/*=============================================================
 Authour URI: www.binarycart.com
 Version: 1.1
 License: MIT

 http://opensource.org/licenses/MIT

 100% To use For Personal And Commercial Use.

 ========================================================  */

$(document).ready(function(){

    $("#btnConfirmarInscricao").click(function(){
        var dataTreinamento = $("#cmbDataTreinamento").val();
        if(dataTreinamento == "Selecione a data do treinamento"){
            $("#divDataTreinamento").removeClass("has-feedback");
            $("#divDataTreinamento").addClass("has-error");
            return false;
        }else{
            $("#divDataTreinamento").removeClass("has-error");
            $("#divDataTreinamento").addClass("has-success");
        }
    });
    //validar nome
    $("#btnConfirmarInscricao").click(function(){

        nomeCompleto = $("#txtNomeCompleto").val();
        if(nomeCompleto === ""){
            $("#divNomeCompleto").removeClass("has-feedback");
            $("#divNomeCompleto").addClass("has-error");
            return false;
        }
        else {
            $("#divNomeCompleto").removeClass("has-error");
            $("#divNomeCompleto").addClass("has-success");

        }
    });
    //validar cargo
    $("#btnConfirmarInscricao").click(function(){
        cargo = $("#txtCargo").val();
        if(cargo === ""){
            $("#divCargo").removeClass("has-feedback");
            $("#divCargo").addClass("has-error");
            return false;
        }
        else {
            $("#divCargo").removeClass("has-error");
            $("#divCargo").addClass("has-success");

        }
    });

    //validar rg
    $("#btnConfirmarInscricao").click(function(){
        var rg = $("#txtRG").val();
        if(rg === ""){
            $("#divRG").removeClass("has-feedback");
            $("#divRG").addClass("has-error");
            return false;
        }
        else {
            var posRG = rg.substring(0,2);
            if(isNaN(posRG) == false){
                $("#divRG").removeClass("has-feedback");
                $("#divRG").addClass("has-error");
                return false;
            }else{
                $("#divRG").removeClass("has-error");
                $("#divRG").addClass("has-success");

            }
        }
    });
    //validar cpf
    $("#btnConfirmarInscricao").click(function(){
        var cpf = $("#txtCPF").val();

        if(is_cpf(cpf) === false){
            $("#divCPF").removeClass("has-feedback");
            $("#divCPF").addClass("has-error");
            return false;
        }else{
            $("#divCPF").removeClass("has-error");
            $("#divCPF").addClass("has-success");        }
    });
    //validar telefone fixo
    $("#btnConfirmarInscricao").click(function(){
        var telefoneFixo = $("#txtTelefoneFixo").val();
        if(telefoneFixo === ""){
            $("#divTelefoneFixo").removeClass("has-feedback");
            $("#divTelefoneFixo").addClass("has-error");
            return false;
        }
        else {
            $("#divTelefoneFixo").removeClass("has-error");
            $("#divTelefoneFixo").addClass("has-success");

        }
    });

    //validar celular

    //validar email
    $("#btnConfirmarInscricao").click(function(){
        var email = $("#txtEmail").val();
        if(email == ""){
            $("#divEmail").removeClass("has-feedback");
            $("#divEmail").addClass("has-error");
            return false;
        }else{
            if(is_email(email) == false){
                $("#divEmail").removeClass("has-feedback");
                $("#divEmail").addClass("has-error");
                return false;
            }else{
                $("#divEmail").removeClass("has-error");
                $("#divEmail").addClass("has-success");

            }
        }
    });


    $("#btnConfirmarInscricao").click(function(){
        var tempoExperiencia = $("#txtTempoExperciencia").val();
        if(tempoExperiencia == ""){
            $("#divTempoExperiencia").removeClass("has-feedback");
            $("#divTempoExperiencia").addClass("has-error");
            return false;
        }else{
            $("#divTempoExperiencia").removeClass("has-error");
            $("#divTempoExperiencia").addClass("has-success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var cnpj = $("#txtCNPJ").val();

        if(!is_cnpj(cnpj)){
            $("#divCNPJ").removeClass("has-feedback");
            $("#divCNPJ").addClass("has-error");
            return false;
        }else {
            $("#divCNPJ").removeClass("has-error");
            $("#divCNPJ").addClass("has-success");
        }
    });
    $("#btnConfirmarInscricao").click(function(){
        var razaoSocial = $("#txtRazaoSocial").val();
        if(razaoSocial == ""){
            $("#divRazaoSocial").removeClass("has-feedback");
            $("#divRazaoSocial").addClass("has-error");
            return false;
        }else{
            $("#divRazaoSocial").removeClass("has-error");
            $("#divRazaoSocial").addClass("has-success");
        }
    });
    $("#btnConfirmarInscricao").click(function(){
        var nomeFantasia = $("#txtNomeFantasia").val();
        if(nomeFantasia == ""){

            $("#divNomeFantasia").removeClass("has-feedback");
            $("#divNomeFantasia").addClass("has-error");
            return false;
        }else{
            $("#divNomeFantasia").removeClass("has-error");
            $("#divNomeFantasia").addClass("has-success");
        }
    });
    $("#btnConfirmarInscricao").click(function(){
        var telefoneComercial1 = $("#txtTelefoneComercial1").val();
        if(telefoneComercial1 == ""){

            $("#divTelefoneComercial1").removeClass("has-feedback");
            $("#divTelefoneComercial1").addClass("has-error");
            return false;
        }else{
            $("#divTelefoneComercial1").removeClass("has-error");
            $("#divTelefoneComercial1").addClass("has-success");
        }
    });


    $("#btnConfirmarInscricao").click(function(){
        var escolaridade = $("input[type='radio'][name='rdbEscolaridade']:checked").val();
        if(escolaridade == undefined){
            $("#divEscolaridade").addClass("error");
            return false;
        }else{
            $("#divEscolaridade").removeClass("error");
            $("#divEscolaridade").addClass("success");
        }
    });


    $("#btnConfirmarInscricao").click(function () {
        var protocoloImpressao = $("input[type='radio'][id='rdbProtocoloImpressao']:checked").val();
        if(protocoloImpressao == undefined){
            $("#divProtocoloImpressao").addClass("error");
            return false;
        }else{
            $("#divProtocoloImpressao").removeClass("error");
            $("#divProtocoloImpressao").addClass("success");
        }
    });
    $("#btnConfirmarInscricao").click(function(){
        var filaImpressao =  $("input[type='radio'][id='rdbFilaImpressao']:checked").val();
        if(filaImpressao == undefined){
            $("#divFilaImpressao").addClass("error");
            return false;
        }else{
            $("#divFilaImpressao").removeClass("error");
            $("#divFilaImpressao").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbTcpIp']:checked").val();
        if(tcpIp == undefined){
            $("#divTcpIp").addClass("error");
            return false;
        }else{
            $("#divTcpIp").removeClass("error");
            $("#divTcpIp").addClass("success");
        }
    });

    //validando os checkbox
    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbGPO']:checked").val();
        if(tcpIp == undefined){
            $("#divGPO").addClass("error");
            return false;
        }else{
            $("#divGPO").removeClass("error");
            $("#divGPO").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbAD']:checked").val();
        if(tcpIp == undefined){
            $("#divAD").addClass("error");
            return false;
        }else{
            $("#divAD").removeClass("error");
            $("#divAD").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbScripts']:checked").val();
        if(tcpIp == undefined){
            $("#divScripts").addClass("error");
            return false;
        }else{
            $("#divScripts").removeClass("error");
            $("#divScripts").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbUsuariosGrupos']:checked").val();
        if(tcpIp == undefined){
            $("#divUsuariosGrupos").addClass("error");
            return false;
        }else{
            $("#divUsuariosGrupos").removeClass("error");
            $("#divUsuariosGrupos").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbTcpIp']:checked").val();
        if(tcpIp == undefined){
            $("#divTcpIp").addClass("error");
            return false;
        }else{
            $("#divTcpIp").removeClass("error");
            $("#divTcpIp").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbRedesComputadores']:checked").val();
        if(tcpIp == undefined){
            $("#divRedesComputadores").addClass("error");
            return false;
        }else{
            $("#divRedesComputadores").removeClass("error");
            $("#divRedesComputadores").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbFirewall']:checked").val();
        if(tcpIp == undefined){
            $("#divFirewall").addClass("error");
            return false;
        }else{
            $("#divFirewall").removeClass("error");
            $("#divFirewall").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbPapercutNG']:checked").val();
        if(tcpIp == undefined){
            $("#divPapercutNG").addClass("error");
            return false;
        }else{
            $("#divPapercutNG").removeClass("error");
            $("#divPapercutNG").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbDispositivos']:checked").val();
        if(tcpIp == undefined){
            $("#divDispositivos").addClass("error");
            return false;
        }else{
            $("#divDispositivos").removeClass("error");
            $("#divDispositivos").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbPapercutMF']:checked").val();
        if(tcpIp == undefined){
            $("#divPapercutMF").addClass("error");
            return false;
        }else{
            $("#divPapercutMF").removeClass("error");
            $("#divPapercutMF").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbImpressoras']:checked").val();
        if(tcpIp == undefined){
            $("#divImpressoras").addClass("error");
            return false;
        }else{
            $("#divImpressoras").removeClass("error");
            $("#divImpressoras").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbEstacaoLiberacao']:checked").val();
        if(tcpIp == undefined){
            $("#divEstacaoLiberacao").addClass("error");
            return false;
        }else{
            $("#divEstacaoLiberacao").removeClass("error");
            $("#divEstacaoLiberacao").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbGruposDeUsuarios']:checked").val();
        if(tcpIp == undefined){
            $("#divGruposDeUsuarios").addClass("error");
            return false;
        }else{
            $("#divGruposDeUsuarios").removeClass("error");
            $("#divGruposDeUsuarios").addClass("success");
        }
    });

    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbConfiguracaoEmail']:checked").val();
        if(tcpIp == undefined){
            $("#divConfiguracaoEmail").addClass("error");
            return false;
        }else{
            $("#divConfiguracaoEmail").removeClass("error");
            $("#divConfiguracaoEmail").addClass("success");
        }
    });
    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbCotasUsuarios']:checked").val();
        if(tcpIp == undefined){
            $("#divCotasUsuario").addClass("error");
            return false;
        }else{
            $("#divCotasUsuario").removeClass("error");
            $("#divCotasUsuario").addClass("success");
        }
    });
    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbCartaoLiberacao']:checked").val();
        if(tcpIp == undefined){
            $("#divCartaoLiberacao").addClass("error");
            return false;
        }else{
            $("#divCartaoLiberacao").removeClass("error");
            $("#divCartaoLiberacao").addClass("success");
        }
    });
    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbSegurancaImpressao']:checked").val();
        if(tcpIp == undefined){
            $("#divSegurancaImpressoras").addClass("error");
            return false;
        }else{
            $("#divSegurancaImpressoras").removeClass("error");
            $("#divSegurancaImpressoras").addClass("success");
        }
    });
    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbFilasVirtuais']:checked").val();
        if(tcpIp == undefined){
            $("#divFilasVirtuais").addClass("error");
            return false;
        }else{
            $("#divFilasVirtuais").removeClass("error");
            $("#divFilasVirtuais").addClass("success");
        }
    });
    $("#btnConfirmarInscricao").click(function(){
        var tcpIp = $("input[type='radio'][id='rdbFiltrosRestricoes']:checked").val();
        if(tcpIp == undefined){
            $("#divFiltrosRestricoes").addClass("error");
            return false;
        }else{
            $("#divFiltrosRestricoes").removeClass("error");
            $("#divFiltrosRestricoes").addClass("success");
        }
    });

    $("#rdbEscolaridadeESC").on('click',function() {
        if($(this).is(':checked')) {
            document.getElementById("txtAreaFormacao").disabled = false;
            $("#btnConfirmarInscricao").click(function(){
                var areaFormacao = $("#txtAreaFormacao").val();
                if(areaFormacao == ""){

                    $("#divAreaFormacao").removeClass("has-feedback");
                    $("#divAreaFormacao").addClass("has-error");
                    return false;
                }else{
                    $("#divAreaFormacao").removeClass("has-error");
                    $("#divAreaFormacao").addClass("has-success");
                }
            });
        }
    });
    $("#rdbEscolaridadeESI").on('click',function() {
        if($(this).is(':checked')) {
            document.getElementById("txtAreaFormacao").disabled = false;
            $("#btnConfirmarInscricao").click(function(){
                var areaFormacao = $("#txtAreaFormacao").val();
                if(areaFormacao == ""){

                    $("#divAreaFormacao").removeClass("has-feedback");
                    $("#divAreaFormacao").addClass("has-error");
                    return false;
                }else{
                    $("#divAreaFormacao").removeClass("has-error");
                    $("#divAreaFormacao").addClass("has-success");
                }
            });
        }
    });
    $("#rdbEscolaridadeET").on('click',function() {
        if($(this).is(':checked')) {
            document.getElementById("txtAreaFormacao").disabled = false;
            $("#btnConfirmarInscricao").click(function(){
                var areaFormacao = $("#txtAreaFormacao").val();
                if(areaFormacao == ""){

                    $("#divAreaFormacao").removeClass("has-feedback");
                    $("#divAreaFormacao").addClass("has-error");
                    return false;
                }else{
                    $("#divAreaFormacao").removeClass("has-error");
                    $("#divAreaFormacao").addClass("has-success");
                }
            });
        }
    });
    $("#rdbEscolaridadePG").on('click',function() {
        if($(this).is(':checked')) {
            document.getElementById("txtAreaFormacao").disabled = false;
            $("#btnConfirmarInscricao").click(function(){
                var areaFormacao = $("#txtAreaFormacao").val();
                if(areaFormacao == ""){

                    $("#divAreaFormacao").removeClass("has-feedback");
                    $("#divAreaFormacao").addClass("has-error");
                    return false;
                }else{
                    $("#divAreaFormacao").removeClass("has-error");
                    $("#divAreaFormacao").addClass("has-success");
                }
            });

        }
    });

    $("#rdbEscolaridadeEM").on('click',function() {
        if($(this).is(':checked')) {
            document.getElementById("txtAreaFormacao").disabled = true;

        }
    });
    $("#btnConfirmarInscricao").click(function(){
        var aceito = $("input[type='checkbox'][name='chkTermosContrato']:checked").val();
        if(aceito === undefined){
            $(".erroTermos").html("Voce deve aceitar os termos do contrato!")
        }else{
            $(".erroTermos").html("");
        }
    });


    //fun��o para validar cnpj
    function is_cnpj(cnpj){
        cnpj = cnpj.replace(/[^\d]+/g, '');

        if (cnpj == '') return false;

        if (cnpj.length != 14)
            return false;

        // Elimina CNPJs invalidos conhecidos
        if (cnpj == "00000000000000" ||
            cnpj == "11111111111111" ||
            cnpj == "22222222222222" ||
            cnpj == "33333333333333" ||
            cnpj == "44444444444444" ||
            cnpj == "55555555555555" ||
            cnpj == "66666666666666" ||
            cnpj == "77777777777777" ||
            cnpj == "88888888888888" ||
            cnpj == "99999999999999")
            return false;

        // Valida DVs
        tamanho = cnpj.length - 2
        numeros = cnpj.substring(0, tamanho);
        digitos = cnpj.substring(tamanho);
        soma = 0;
        pos = tamanho - 7;
        for (i = tamanho; i >= 1; i--) {
            soma += numeros.charAt(tamanho - i) * pos--;
            if (pos < 2)
                pos = 9;
        }
        resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
        if (resultado != digitos.charAt(0))
            return false;

        tamanho = tamanho + 1;
        numeros = cnpj.substring(0, tamanho);
        soma = 0;
        pos = tamanho - 7;
        for (i = tamanho; i >= 1; i--) {
            soma += numeros.charAt(tamanho - i) * pos--;
            if (pos < 2)
                pos = 9;
        }
        resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
        if (resultado != digitos.charAt(1))
            return false;

        return true;
    }
    //fun��o para validar email
    function is_email(email) {
        er = /^[a-zA-Z0-9][a-zA-Z0-9\._-]+@([a-zA-Z0-9\._-]+\.)[a-zA-Z-0-9]{2,3}/;
        if (!er.exec(email)) {
            return false;
        }
    }
    //validacao para validar cpf
    function is_cpf(cpf){
        cpf = cpf.replace(/[^\d]+/g,'');
        if(cpf == '') return false;
        // Elimina CPFs invalidos conhecidos
        if (cpf.length != 11 ||
            cpf == "00000000000" ||
            cpf == "11111111111" ||
            cpf == "22222222222" ||
            cpf == "33333333333" ||
            cpf == "44444444444" ||
            cpf == "55555555555" ||
            cpf == "66666666666" ||
            cpf == "77777777777" ||
            cpf == "88888888888" ||
            cpf == "99999999999")
            return false;
        // Valida 1o digito
        add = 0;
        for (i=0; i < 9; i ++)
            add += parseInt(cpf.charAt(i)) * (10 - i);
        rev = 11 - (add % 11);
        if (rev == 10 || rev == 11)
            rev = 0;
        if (rev != parseInt(cpf.charAt(9)))
            return false;
        // Valida 2o digito
        add = 0;
        for (i = 0; i < 10; i ++)
            add += parseInt(cpf.charAt(i)) * (11 - i);
        rev = 11 - (add % 11);
        if (rev == 10 || rev == 11)
            rev = 0;
        if (rev != parseInt(cpf.charAt(10)))
            return false;
        return true;
    }


});

/* M�scaras ER */
function mascara(o, f) {
    v_obj = o;
    v_fun = f;
    setTimeout(execmascara, 1);
}
function execmascara() {
    v_obj.value = v_fun(v_obj.value)
}
function mcep(v){
    v=v.replace(/\D/g,"")                    //Remove tudo o que n�o � d�gito
    v=v.replace(/^(\d{5})(\d)/,"$1-$2")         //Esse � t�o f�cil que n�o merece explica��es
    return v
}
function mtel(v){
    v=v.replace(/\D/g,"");             //Remove tudo o que n�o � d�gito
    v=v.replace(/^(\d{2})(\d)/g,"($1) $2"); //Coloca par�nteses em volta dos dois primeiros d�gitos
    v=v.replace(/(\d)(\d{4})$/,"$1-$2");    //Coloca h�fen entre o quarto e o quinto d�gitos
    return v;
}
function cnpj(v){
    v=v.replace(/\D/g,"")                           //Remove tudo o que n�o � d�gito
    v=v.replace(/^(\d{2})(\d)/,"$1.$2")             //Coloca ponto entre o segundo e o terceiro d�gitos
    v=v.replace(/^(\d{2})\.(\d{3})(\d)/,"$1.$2.$3") //Coloca ponto entre o quinto e o sexto d�gitos
    v=v.replace(/\.(\d{3})(\d)/,".$1/$2")           //Coloca uma barra entre o oitavo e o nono d�gitos
    v=v.replace(/(\d{4})(\d)/,"$1-$2")              //Coloca um h�fen depois do bloco de quatro d�gitos
    return v
}
function mcpf(v){
    v=v.replace(/\D/g,"")                    //Remove tudo o que n�o � d�gito
    v=v.replace(/(\d{3})(\d)/,"$1.$2")       //Coloca um ponto entre o terceiro e o quarto d�gitos
    v=v.replace(/(\d{3})(\d)/,"$1.$2")       //Coloca um ponto entre o terceiro e o quarto d�gitos
                                             //de novo (para o segundo bloco de n�meros)
    v=v.replace(/(\d{3})(\d{1,2})$/,"$1-$2") //Coloca um h�fen entre o terceiro e o quarto d�gitos
    return v
}
function mdata(v){
    v=v.replace(/\D/g,"");                    //Remove tudo o que n�o � d�gito
    v=v.replace(/(\d{2})(\d)/,"$1/$2");
    v=v.replace(/(\d{2})(\d)/,"$1/$2");

    v=v.replace(/(\d{2})(\d{2})$/,"$1$2");
    return v;
}
function mtempo(v){
    v=v.replace(/\D/g,"");                    //Remove tudo o que n�o � d�gito
    v=v.replace(/(\d{1})(\d{2})(\d{2})/,"$1:$2.$3");
    return v;
}
function mhora(v){
    v=v.replace(/\D/g,"");                    //Remove tudo o que n�o � d�gito
    v=v.replace(/(\d{2})(\d)/,"$1h$2");
    return v;
}
/*
 function mrg(v){
 v=v.replace(/(\d)(\d{7})$/,"$1.$2");    //Coloca o . antes dos �ltimos 3 d�gitos, e antes do verificador
 v=v.replace(/(\d)(\d{4})$/,"$1.$2");    //Coloca o . antes dos �ltimos 3 d�gitos, e antes do verificador
 v=v.replace(/(\d)(\d)$/,"$1-$2");               //Coloca o - antes do �ltimo d�gito
 return v;
 }
 */
function mnum(v){
    v=v.replace(/\D/g,"");                                      //Remove tudo o que n�o � d�gito
    return v;
}
function mvalor(v){
    v=v.replace(/\D/g,"");//Remove tudo o que n�o � d�gito
    v=v.replace(/(\d)(\d{8})$/,"$1.$2");//coloca o ponto dos milh�es
    v=v.replace(/(\d)(\d{5})$/,"$1.$2");//coloca o ponto dos milhares

    v=v.replace(/(\d)(\d{2})$/,"$1,$2");//coloca a virgula antes dos 2 �ltimos d�gitos
    return v;
}
function id( el ){
    return document.getElementById( el );
}
window.onload = function(){
    id('txtCPF').onkeyup = function(){
        mascara( this, mcpf );
    }
    id('txtTelefoneFixo').onkeyup = function(){
        mascara( this, mtel);
    }
    id('txtTelefoneCelular').onkeyup = function(){
        mascara( this, mtel);
    }
    id('txtCNPJ').onkeyup = function(){
        mascara(this,cnpj)
    }
    id('txtTelefoneComercial1').onkeyup = function(){
        mascara(this,mtel)
    }
    id('txtTelefoneComercial2').onkeyup = function(){
        mascara(this,mtel)
    }
}

