<?php

     // definição que roda no servidor
    header('Content-Type: text/html; charset=UTF-8');
    define('DB_HOST','database-mysql.comtcpwnnann.us-west-2.rds.amazonaws.com' );
    define('DB_NAME', 'eco_portaldb_homolog');
    define('DB_USER', 'eco_portaluser');
    define('DB_PASS', 'fXLLbGI[MSniO4#}*3');
?>
