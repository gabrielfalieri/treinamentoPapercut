<?php
require_once("DB.php");
/**
 * Created by PhpStorm.
 * User: gabriel.falieri
 * Date: 15/09/2016
 * Time: 09:02
 */

abstract class enum{
    const Error = 'Error';
    const Warning = 'Warning';
    const Debug = 'Debug';
}

class ExceptionDatabase extends DB
{
    public $prt_syslog = "prt_syslog";
    public $tipoLog;
    public $titleLog;
    public $descLog;
    public $dataRegistro;
    public $arquivo;
    public $arquivoLog;
    public $tabela;
    public $erro;
    public $mensagem;

    public function setTipoLog($tipoLog){
        return $this->tipoLog = $tipoLog;
    }
    public function  setTitleLog($titleLog){
        return $this->titleLog = $titleLog;
    }
    public function setDescLog($descLog){
        return $this->descLog = $descLog;
    }
    public function setDataRegistro($dataRegistro){
        return $this->dataRegistro = $dataRegistro;
    }
    public function setArquivo($arquivo){
        $this->arquivo = $arquivo;
    }
    public function setArquivoLog($arquivoLog){
        $this->arquivoLog = $arquivoLog;
    }
    public function setTabela($tabela){
        $this->tabela = $tabela;
    }
    public function setErro($erro){
        $this->erro = $erro;
    }
    public function setMensagem($mensagem){
        $this->mensagem = $mensagem;
    }



    public function insertLog(){
        try{

            $sql = "INSERT INTO $this->prt_syslog(id_log,tipo_log,tit_log,desc_log,_data_registro) VALUES (NULL,:tipoLog, :title,:descLog, :dataRegistro)";
            $stmt = DB::prepare($sql);
            $stmt->bindParam(":tipoLog",$this->tipoLog,PDO::PARAM_STR);
            $stmt->bindParam(":title",$this->titleLog,PDO::PARAM_STR);
            $stmt->bindParam(":descLog",$this->descLog,PDO::PARAM_STR);
            $stmt->bindParam(":dataRegistro",$this->dataRegistro,PDO::PARAM_STR);

            return $stmt->execute();

        }
        catch(PDOException $ex){
           $ex->getMessage();
        }

    }

    function erro()
    {


        self::insertLog();
        switch($this->erro)
        {

            // se aparecer algum erro n�o conhecido
            default:
                echo $this->mensagem;
                echo 'Erro n�: '.$this->erro. "<br/>
				<li  class='text-danger'>
				Erro n�o conhecido.<br/>
				 Favor contate o desenvolvedor para resolver o problema.</li>";
                $this->erroMSG = $this->mensagem;
                $texto = "Nome do arquivo:".$this->arquivo."\n
Codigo do erro: ".$this->erro."\n
Erro gerado: ".$this->erro.PHP_EOL;
                file_put_contents($this->arquivoLog,$texto,FILE_APPEND);


                break;
        }
    }
}