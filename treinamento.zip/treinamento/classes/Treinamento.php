<?php
require_once("Crud.php");
/**
 * Created by PhpStorm.
 * User: gabriel.falieri
 * Date: 07/10/2016
 * Time: 13:39
 */


class Treinamento extends crudTreinamento{
    public $cnpj;
    public $razao_social;
    public $nomeFantasia;
    public $tel_comercial1;
    public $tel_comercial2;

    public $nome;
    public $cargo;
    public $rg;
    public $cpf;
    public $tel_fixo;
    public $tel_cel;
    public $email;
    public $escolaridade;
    public $formacao;
    public $tempo_experiencia;
    public $aceite;
    public $data_registro;
    public $ip_registro;
    public $id_trein_pj;
    public $id_treinamento;
    public $id_trein_pf;
    public $resposta = array();



    //setters of manufactures

    public function setCNPJ($cnpj){
        return $this->cnpj = $cnpj;
    }
    public function setRazaoSocial($razaoSocial){
        return $this->razao_social = $razaoSocial;
    }
    public function setNomeFantasia($nomeFantasia){
        return $this->nomeFantasia = $nomeFantasia;
    }
    public function setTelComercial1($telComercial1){
        return $this->tel_comercial1 = $telComercial1;
    }
    public function setTelComercial2($telComercial2){
        return $this->tel_comercial2 = $telComercial2;
    }
    //setters of peoples
    public function  setNome($nome){
        return $this->nome = $nome;
    }
    public function setCargo($cargo){
        return $this->cargo = $cargo;
    }
    public function setRG($rg){
        return $this->rg = $rg;
    }
    public function setCPF($cpf){
        return $this->cpf = $cpf;
    }
    public function setTelFixo($telFixo){
        return $this->tel_fixo = $telFixo;
    }
    public function setTelCel($celular){
        return $this->tel_cel = $celular;
    }
    public function setEmail($email){
        return $this->email = $email;
    }
    public function setEscolaridade($escolaridade){
        return $this->escolaridade = $escolaridade;
    }
    public function setFormacao($formacao){
        return $this->formacao = $formacao;
    }
    public function setTempoExperciencia($tempoExperiencia){
        return $this->tempo_experiencia = $tempoExperiencia;
    }
    public function setAceite($aceite){
        return $this->aceite = $aceite;
    }
    public function setDataRegistro($dataRegistro){
        return $this->data_registro = $dataRegistro;
    }
    public function setIPRegistro($ipRegistro){
        return $this->ip_registro = $ipRegistro;
    }
    public function setTreinPJ($idTreinPJ){
        return $this->id_trein_pj = $idTreinPJ;
    }
    public function setIDTreinamento($treinamento){
        return $this->id_treinamento = $treinamento;
    }

    public function setIDPF($idPF){
        return $this->id_trein_pf = $idPF;
    }
    public function setResp($resp){
        return $this->resposta = $resp;
    }
    public function insert(){
        try{

            self::getInstance()->beginTransaction();
            self::getInstance()->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            //insert manufactures
            $insertPJ = "INSERT into trein_pj VALUES ( NULL,:cnpj,:razao_social,:nome_fantasia,:tel_comercial1,:tel_comercial2)";
            $stmt = DB::prepare($insertPJ);
            $stmt->bindParam(":cnpj",$this->cnpj,PDO::PARAM_STR);
            $stmt->bindParam(":razao_social",$this->razao_social,PDO::PARAM_STR);
            $stmt->bindParam(":nome_fantasia",$this->nomeFantasia,PDO::PARAM_STR);
            $stmt->bindParam(":tel_comercial1",$this->tel_comercial1,PDO::PARAM_STR);
            $stmt->bindParam(":tel_comercial2",$this->tel_comercial2,PDO::PARAM_STR);
            $stmt->execute();

            $this->id_trein_pj = DB::getInstance()->lastInsertId();

            //insert peoples
            $insertPF = "INSERT INTO trein_pf VALUES (NULL,:nome,:cargo,:rg,:cpf,:tel_fixo,:tel_celular,:email,:escolaridade,:formacao,:tempo_experciencia,:aceite,:data_registro,:ip_registro,:id_trein_pj,:id_treinamento)";

            $stmt = DB::prepare($insertPF);
            $stmt->bindParam(":nome",$this->nome,PDO::PARAM_STR);
            $stmt->bindParam(":cargo",$this->cargo,PDO::PARAM_STR);
            $stmt->bindParam(":rg",$this->rg,PDO::PARAM_STR);
            $stmt->bindParam(":cpf",$this->cpf,PDO::PARAM_STR);
            $stmt->bindParam(":tel_fixo",$this->tel_fixo,PDO::PARAM_STR);
            $stmt->bindParam(":tel_celular",$this->tel_celular,PDO::PARAM_STR);
            $stmt->bindParam(":email",$this->email,PDO::PARAM_STR);
            $stmt->bindParam(":escolaridade",$this->escolaridade,PDO::PARAM_STR);
            $stmt->bindParam(":formacao",$this->formacao,PDO::PARAM_STR);
            $stmt->bindParam(":tempo_experciencia",$this->tempo_experiencia,PDO::PARAM_STR);
            $stmt->bindParam(":aceite",$this->aceite,PDO::PARAM_STR);
            $stmt->bindParam(":data_registro",$this->data_registro,PDO::PARAM_STR);
            $stmt->bindParam(":ip_registro",$this->ip_registro,PDO::PARAM_STR);
            $stmt->bindParam(":id_trein_pj",$this->id_trein_pj,PDO::PARAM_INT);
            $stmt->bindParam(":id_treinamento",$this->id_treinamento, PDO::PARAM_INT);

            $stmt->execute();
            $this->id_trein_pf = DB::getInstance()->lastInsertId();

            $i = 0;
            foreach($this->resposta as $key => $v){
                $i++;
                $insertConhecimentos = "INSERT INTO trein_conhecimento VALUES(:_id_conhec_topico,:_id_trein_pf,:resposta); ";
                $stmt = DB::prepare($insertConhecimentos);
                $stmt->bindParam(":_id_conhec_topico",$i,PDO::PARAM_INT);

                $stmt->bindParam(":_id_trein_pf",$this->id_trein_pf,PDO::PARAM_INT);

                $stmt->bindParam(":resposta",$this->resposta[$key],PDO::PARAM_STR);
                $stmt->execute();
            }
           /* for ($i = 1; $i < $tamResp; $i++){



            }*/
            $stmt->closeCursor();

            if (self::getInstance()->commit()) {
                return true;
            }

        }catch (PDOException $ex){
            echo $ex->getMessage();
            self::getInstance()->rollBack();
        }
    }
    public function update(){
        try{
        }catch (PDOException $ex){
            self::getInstance()->rollBack();
        }
    }

}