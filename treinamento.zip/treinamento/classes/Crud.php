<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Crud
 *
 * @author gabriel.falieri
 */
require_once 'DB.php';
require_once ("Exception.php");

abstract class crudTreinamento extends DB
{
    abstract public function insert();
    abstract public function update();
function getDates(){
        try{
            $sql = "SELECT id_treinamento, data_inicio,data_fim,local FROM treinamento WHERE data_inicio > current_timestamp();";
            $stmt = DB::prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll();
        }catch (PDOException $ex){
            $ex->getMessage();
        }
    }

}
?>
