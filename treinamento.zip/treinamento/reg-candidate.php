<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <link rel="shortcut icon" href="assets/images/vavicon.png" type="image/x-icon" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Formulário de inscrição</title>
    <!-- BOOTSTRAP STYLES-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLES-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- MORRIS CHART STYLES-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
    <!-- CUSTOM STYLES-->
    <link href="assets/css/custom.css" rel="stylesheet" />
    <!-- GOOGLE FONTS-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
<div id="wrapper">
    <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">

            <a class="navbar-brand" href="index.php"><img src="assets/images/logo.png" alt="Logo_Ecoprint"></a>
        </div>

    </nav>
    <!-- /. NAV TOP  -->

    <?php
    require_once("classes/Treinamento.php");
    $Treinamento = new Treinamento();
    ?>

    <!-- /. NAV SIDE  -->
    <div id="page-wrapper" >
        <div id="page-inner">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" >
                    <h2>Formulário de inscrição</h2>
                </div><hr>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

                    <form method="post" action="">
                        <fieldset>
                            <legend>
                                Treinamento
                            </legend>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <label for="cmbDataTreinamento">Data do treinamento: </label>

                                <div class="input-group has-feedback" id="divDataTreinamento">
                                    <div class="input-group-addon">
                                        <i class="fa fa-calendar"></i>
                                    </div>
                                    <select class="form-control input-group-sm" name="cmbDataTreinamento" id="cmbDataTreinamento">
                                        <option>Selecione a data do treinamento</option>
                                        <?php
                                        foreach($Treinamento->getDates() as $key => $values):
                                            ?>
                                            <option value="<?php echo $values->id_treinamento; ?>"><?php echo date("d/m/Y",strtotime($values->data_inicio)); ?> a <?php echo date("d/m/Y",strtotime($values->data_fim)); ?> - <?php echo $values->local ?> </option>

                                            <?php
                                        endforeach;
                                        ?>
                                    </select>

                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Dados do candidato (pessoa física)</legend>



                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <label for="txtNomeCompleto">Nome Completo: </label>

                                <div class="input-group has-feedback" id="divNomeCompleto">
                                    <div class="input-group-addon">
                                        <i class="fa fa-users"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtNomeCompleto" placeholder="Ex.: Fulano da Silva"
                                           id="txtNomeCompleto" autocomplete="off" maxlength="250">
                                </div>
                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <label for="txtCargo">Cargo: </label>

                                <div class="input-group has-feedback" id="divCargo">
                                    <div class="input-group-addon">
                                        <i class="fa fa-user"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtCargo" placeholder="Ex.: Técnico"
                                           id="txtCargo" autocomplete="off" maxlength="100">
                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                <label for="txtRg">Rg: </label>

                                <div class="input-group has-feedback" id="divRG">
                                    <div class="input-group-addon">
                                        <i class="fa fa-list-alt"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtRG" placeholder="Ex.: mg 00000000"
                                           id="txtRG" autocomplete="off" maxlength="10">
                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                <label for="txtCPF">Cpf: </label>

                                <div class="input-group has-feedback" id="divCPF">
                                    <div class="input-group-addon">
                                        <i class="fa fa-list-alt"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtCPF" placeholder="Ex.:000.000.000-00"
                                           id="txtCPF" autocomplete="off" maxlength="14" ">
                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                <label for="txtTelefoneFixo">Telefone Fixo: </label>

                                <div class="input-group has-feedback" id="divTelefoneFixo">
                                    <div class="input-group-addon">
                                        <i class="fa fa-phone"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtTelefoneFixo" placeholder="Ex.: (00) 0000-0000"
                                           id="txtTelefoneFixo" autocomplete="off" maxlength="14">
                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                <label for="txtTelefoneCelular">Telefone Celular: </label>

                                <div class="input-group has-feedback" id="divTelefoneCelular">
                                    <div class="input-group-addon">
                                        <i class="fa fa-mobile-phone"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtTelefoneCelular" placeholder="Ex.: (00) 00000-0000"
                                           id="txtTelefoneCelular" autocomplete="off" maxlength="15">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <label for="txtEmail">Email: </label>

                                <div class="input-group has-feedback" id="divEmail">
                                    <div class="input-group-addon">
                                        <i class="fa fa-envelope"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtEmail" placeholder="Ex.: joao@email.com.br"
                                           id="txtEmail" autocomplete="off" maxlength="64">
                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divEscolaridade">
                                <label for="rdbEscolaridade">Escolaridade: </label>

                                <div class="input-group has-feedback" >


                                    <input type="radio" id="rdbEscolaridadeEF" value="Ensino Fundamental" name="rdbEscolaridade">Ensino Fundamental<br>
                                    <input type="radio" id="rdbEscolaridadeEM" value="Ensino Médio" name="rdbEscolaridade">Ensino Médio<br>
                                    <input type="radio" id="rdbEscolaridadeET" value="Ensino Técnico" name="rdbEscolaridade">Ensino Técnico<br>
                                    <input type="radio" id="rdbEscolaridadeESI" value="Ensino Superior Incompleto" name="rdbEscolaridade">Ensino Superior Incompleto<br>
                                    <input type="radio" id="rdbEscolaridadeESC" value="Ensino Superior Completo" name="rdbEscolaridade">Ensino Superior Completo<br>
                                    <input type="radio" id="rdbEscolaridadePG" value="Pós Graduação" name="rdbEscolaridade">Pós Graduação


                                </div>

                            </div>

                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <label for="txtAreaFormacao">Area de formação (Em caso de formação técnica/superior): </label>

                                <div class="input-group has-feedback" id="divAreaFormacao">
                                    <div class="input-group-addon">
                                        <i class="fa fa-university"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtAreaFormacao" placeholder="Ex.: Ciência da computação"
                                           id="txtAreaFormacao" autocomplete="off" maxlength="200" disabled>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <label for="txtTempoExperciencia">Tempo de experiência na área de ti: </label>

                                <div class="input-group has-feedback" id="divTempoExperiencia">
                                    <div class="input-group-addon">
                                        <i class="fa fa-clock-o"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtTempoExperciencia" placeholder="Ex.: 4 anos"
                                           id="txtTempoExperciencia" autocomplete="off" maxlength="40">
                                </div>
                            </div>

                        </fieldset>

                        <hr>
                        <fieldset>
                            <legend>Dados da empresa (pessoa jurídica)</legend>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                <label for="txtCNPJ">CNPJ: </label>

                                <div class="input-group has-feedback" id="divCNPJ">
                                    <div class="input-group-addon">
                                        <i class="fa fa-building"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtCNPJ" placeholder="Ex.: 00.000.000/0000-00"
                                           id="txtCNPJ" autocomplete="off" maxlength="18">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <label for="txtRazaoSocial">Razão Social: </label>

                                <div class="input-group has-feedback" id="divRazaoSocial">
                                    <div class="input-group-addon">
                                        <i class="fa fa-list"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtRazaoSocial" placeholder="Ex.: XPTO Serviços Ltda. ME"
                                           id="txtRazaoSocial" autocomplete="off" maxlength="255">
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <label for="txtNomeFantasia">Nome Fantasia: </label>

                                <div class="input-group has-feedback" id="divNomeFantasia">
                                    <div class="input-group-addon">
                                        <i class="fa fa-list"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtNomeFantasia" placeholder="Ex.: XPTO Serviços."
                                           id="txtNomeFantasia" autocomplete="off" maxlength="60">
                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                <label for="txtTelefoneComercial1">Telefone Comercial 1: </label>

                                <div class="input-group has-feedback" id="divTelefoneComercial1">
                                    <div class="input-group-addon">
                                        <i class="fa fa-phone"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtTelefoneComercial1" placeholder="Ex.: (00) 0000-0000"
                                           id="txtTelefoneComercial1" autocomplete="off" maxlength="15">
                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                <label for="txtTelefoneComercial2">Telefone Comercial 2: </label>

                                <div class="input-group has-feedback" id="divTelefoneComercial2">
                                    <div class="input-group-addon">
                                        <i class="fa fa-phone"></i>
                                    </div>
                                    <input type="text" class="form-control input-group"  name="txtTelefoneComercial2" placeholder="Ex.: (00) 0000-0000"
                                           id="txtTelefoneComercial2" autocomplete="off" maxlength="15">
                                </div>
                            </div>
                        </fieldset>
                        <hr>
                        <fieldset>
                            <legend>Informe seu conhecimento</legend>

                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <h4><u>Sobre infraestrutura</u></h4>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6"id="divProtocoloImpressao">
                                <label for="rdbProtocoloImpressao">Protocolos de impressão: </label>

                                <div class="input-group" >

                                    <input type="radio" id="rdbProtocoloImpressao" value="b" name="conhecimento[0]">Baixo
                                    &ensp;&ensp;&ensp; <input type="radio"  id="rdbProtocoloImpressao" value="m" name="conhecimento[0]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio"  id="rdbProtocoloImpressao" value="a" name="conhecimento[0]">Alto

                                </div>

                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divFilaImpressao">
                                <label for="rdbFilaImpressao">Filas de impressão: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbFilaImpressao" value="b" name="conhecimento[1]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbFilaImpressao" value="m" name="conhecimento[1]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbFilaImpressao" value="a" name="conhecimento[1]">Alto

                                </div>


                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divTcpIp">
                                <label for="rdbTcpIp">Protocolo TCP/IP: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbTcpIp" value="b" name="conhecimento[2]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbTcpIp" value="m" name="conhecimento[2]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbTcpIp" value="a" name="conhecimento[2]">Alto

                                </div>

                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divGPO">
                                <label for="rdbGPO">Conhecimentos de GPOs: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbGPO" value="b" name="conhecimento[3]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbGPO" value="m" name="conhecimento[3]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbGPO" value="a" name="conhecimento[3]">Alto

                                </div>

                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divAD">
                                <label for="rdbAD">Conhecimentos de AD's, controladora de domínios: </label>

                                <div class="input-group">

                                    <input type="radio"  id="rdbAD" value="b" name="conhecimento[4]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbAD" value="m" name="conhecimento[4]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbAD" value="a" name="conhecimento[4]">Alto

                                </div>

                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divScripts">
                                <label for="rdbScripts">Conhecimentos em scripts: </label>

                                <div class="input-group">

                                    <input type="radio"  id="rdbScripts" value="b" name="conhecimento[5]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbScripts" value="m" name="conhecimento[5]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbScripts" value="a" name="conhecimento[5]">Alto

                                </div>

                            </div>

                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divUsuariosGrupos">
                                <label for="rdbUsuariosGrupos">Conhecimentos de usuários e grupos: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbUsuariosGrupos" value="b" name="conhecimento[6]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbUsuariosGrupos" value="m" name="conhecimento[6]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbUsuariosGrupos" value="a" name="conhecimento[6]">Alto

                                </div>

                            </div>

                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divRedesComputadores">
                                <label for="rdbRedesComputadores">Conhecimentos geral em redes de computadores: </label>

                                <div class="input-group">

                                    <input type="radio"  id="rdbRedesComputadores" value="b" name="conhecimento[7]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbRedesComputadores" value="m" name="conhecimento[7]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbRedesComputadores" value="a" name="conhecimento[7]">Alto

                                </div>

                            </div>

                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divFirewall">
                                <label for="rdbFirewall">Conhecimentos de firewall: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbFirewall" value="b" name="conhecimento[8]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbFirewall" value="m" name="conhecimento[8]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbFirewall" value="a" name="conhecimento[8]">Alto

                                </div>


                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <h4><u>Sobre o Papercut</u></h4>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divPapercutNG">
                                <label for="rdbPapercutNG">Conhecimento sobre o Papercut NG: </label>

                                <div class="input-group" >

                                    <input type="radio" id="rdbPapercutNG" value="b" name="conhecimento[9]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbPapercutNG" value="m" name="conhecimento[9]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbPapercutNG" value="a" name="conhecimento[9]">Alto

                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divDispositivos">
                                <label for="rdbDispositivos">Conhecimento sobre dispositivos: </label>

                                <div class="input-group">

                                    <input type="radio"  id="rdbDispositivos" value="b" name="conhecimento[10]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbDispositivos" value="m" name="conhecimento[10]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbDispositivos" value="a" name="conhecimento[10]">Alto

                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6"id="divPapercutMF">
                                <label for="rdbPapercutMF">Conhecimento sobre o Papercut MF: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbPapercutMF" value="b" name="conhecimento[11]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbPapercutMF" value="m" name="conhecimento[11]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbPapercutMF" value="a" name="conhecimento[11]">Alto

                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divImpressoras">
                                <label for="rdbImpressoras">Conhecimento sobre impressoras: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbImpressoras" value="b" name="conhecimento[12]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbImpressoras" value="m" name="conhecimento[12]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbImpressoras" value="a" name="conhecimento[12]">Alto

                                </div>
                            </div>


                            <!-- a partir daqui -->
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divEstacaoLiberacao">
                                <label for="rdbEstacaoLiberacao">Conhecimento sobre estação de liberação: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbEstacaoLiberacao" value="b" name="conhecimento[13]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbEstacaoLiberacao" value="m" name="conhecimento[13]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbEstacaoLiberacao" value="a" name="conhecimento[13]">Alto

                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divGruposDeUsuarios">
                                <label for="rdbGruposDeUsuarios">Conhecimento sobre grupos de usuários: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbGruposDeUsuarios" value="b" name="conhecimento[14]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbGruposDeUsuarios" value="m" name="conhecimento[14]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbGruposDeUsuarios" value="a" name="conhecimento[14]">Alto

                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divConfiguracaoEmail">
                                <label for="rdbConfiguracaoEmail">Conhecimento confiuração de e-mail: </label>

                                <div class="input-group">

                                    <input type="radio"  id="rdbConfiguracaoEmail" value="b" name="conhecimento[15]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbConfiguracaoEmail" value="m" name="conhecimento[15]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbConfiguracaoEmail" value="a" name="conhecimento[15]">Alto

                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divCotasUsuario">
                                <label for="rdbCotasUsuarios">Conhecimento sobre cotas de usuários: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbCotasUsuarios" value="b" name="conhecimento[16]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbCotasUsuarios" value="m" name="conhecimento[16]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbCotasUsuarios" value="a" name="conhecimento[16]">Alto

                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divCartaoLiberacao">
                                <label for="rdbCartaoLiberacao">Conhecimento sobre cartão de liberação: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbCartaoLiberacao" value="b" name="conhecimento[17]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbCartaoLiberacao" value="m" name="conhecimento[17]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbCartaoLiberacao" value="a" name="conhecimento[17]">Alto

                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divSegurancaImpressoras">
                                <label for="rdbSegurancaImpressao">Conhecimento sobre segurança de impressoras: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbSegurancaImpressao" value="b" name="conhecimento[18]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbSegurancaImpressao" value="m" name="conhecimento[18]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbSegurancaImpressao" value="a" name="conhecimento[18]">Alto

                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divFilasVirtuais">
                                <label for="rdbFilasVirtuais">Conhecimento sobre filas virtuais: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbFilasVirtuais" value="b" name="conhecimento[19]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbFilasVirtuais" value="m" name="conhecimento[19]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbFilasVirtuais" value="a" name="conhecimento[19]">Alto

                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divFiltrosRestricoes">
                                <label for="rdbFiltrosRestricoes">Conhecimento sobre filtros e restrições: </label>

                                <div class="input-group" >

                                    <input type="radio"  id="rdbFiltrosRestricoes" value="b" name="conhecimento[20]">Baixo
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbFiltrosRestricoes" value="m" name="conhecimento[20]">Médio
                                    &ensp;&ensp;&ensp;<input type="radio" id="rdbFiltrosRestricoes" value="a" name="conhecimento[20]">Alto

                                </div>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6" id="divTermosContrato">


                                <div class="input-group" >

                                    <input type="checkbox"  id="chkTermosContrato" value="1" name="chkTermosContrato"> Aceito os <a style="color: #ff0000" data-toggle="modal" data-target="#termosContrato">termos do treinamento</a>
                                    <div class="error erroTermos"></div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <div class="g-recaptcha" data-sitekey="6LfEeAgUAAAAAFI479kJgp5uOgnx2pOjg9lcDJZm" data-theme="dark"></div>
                            </div><br>
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                <input type="submit" name="btnConfirmarInscricao" value="Confirmar inscrição" class="btn btn-success" id="btnConfirmarInscricao">
                            </div>


                        </fieldset>


                        <?php
                        if(isset($_POST['btnConfirmarInscricao'])):
                            date_default_timezone_set('America/Sao_Paulo');
                            //cad empresas

                            $cnpj = $_POST['txtCNPJ'];
                            $razaoSocial = utf8_decode($_POST['txtRazaoSocial']);
                            $nomeFantasia = utf8_decode($_POST['txtNomeFantasia']);
                            $telefone1 = utf8_decode($_POST['txtTelefoneComercial1']);
                            $telefone2 = utf8_decode($_POST['txtTelefoneComercial2']);

                            $nome = utf8_decode($_POST['txtNomeCompleto']);
                            $cargo = utf8_decode($_POST['txtCargo']);
                            $rg = $_POST['txtRG'];
                            $cpf = $_POST['txtCPF'];
                            $tel_fixo = $_POST['txtTelefoneFixo'];
                            $tel_cel = $_POST['txtTelefoneCelular'];
                            $email = $_POST['txtEmail'];
                            $escolaridade = $_POST['rdbEscolaridade'];
                            if($escolaridade === "Ensino Fundamental" || $escolaridade === "Ensino Médio"){
                                $formacao = utf8_decode("Não possui formação técnica ou superior");
                            }  else{
                                $formacao = utf8_decode($_POST['txtAreaFormacao']);
                            }


                            $tempo_experiencia = $_POST['txtTempoExperciencia'];
                            $aceite = $_POST['chkTermosContrato'];
                            $data_registro = date("y-m-d h:m:s");
                            $ip_registro = $_SERVER['REMOTE_ADDR'];

                            $id_treinamento = $_POST['cmbDataTreinamento'];


                            $treinamento = array();
                            $treinamento = $_POST['conhecimento'];





                            $Treinamento->setCNPJ($cnpj);
                            $Treinamento->setRazaoSocial($razaoSocial);
                            $Treinamento->setNomeFantasia($nomeFantasia);
                            $Treinamento->setTelComercial1($telefone1);
                            $Treinamento->setTelComercial2($telefone2);

                            $Treinamento->setNome($nome);
                            $Treinamento->setCargo($cargo);
                            $Treinamento->setRG($rg);
                            $Treinamento->setCPF($cpf);
                            $Treinamento->setTelFixo($tel_fixo);
                            $Treinamento->setTelCel($tel_cel);
                            $Treinamento->setEmail($email);
                            $Treinamento->setEscolaridade($escolaridade);
                            $Treinamento->setFormacao($formacao);
                            $Treinamento->setTempoExperciencia($tempo_experiencia);
                            $Treinamento->setAceite($aceite);
                            $Treinamento->setDataRegistro($data_registro);
                            $Treinamento->setIPRegistro($ip_registro);


                            $Treinamento->setIDTreinamento($id_treinamento);



                            $Treinamento->setResp($treinamento);

                            if($Treinamento->insert()){
                                echo utf8_encode('Você foi matriculado para o treinamento com sucesso!');
                            }

                        endif
                        ?>

                    </form>

                </div>
            </div>

        </div>
        <!-- /. PAGE INNER  -->
    </div>
    <!-- /. PAGE WRAPPER  -->
</div>

<div class="modal fade" id="termosContrato" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">TERMO DE COMPROMISSO E RESPONSABILIDADE</h4>
            </div>
            <div class="modal-body">
                <h5>Pelo presente TERMO DE COMPROMISSO E RESPONSABILIDADE, referente a  participação no CURSO DE CAPACITAÇÃO TÉCNICA NO PAPERCUT MF, promovido e realizado pela EcoprintQ Brasil, a ser realizado no período de 07/11/2016 a 11/11/2016, na cidade de São Paulo, comprometo-me: </h5>

                <h5>1) Estar de acordo em participar da ação de capacitação e ciente das condições e exigências estabelecidades;</h5>
                <h5>2) Frequentar o evento para o qual fui indicado, como também cumprir horários e a programação do curso;</h5>
                <h5>3) Participar de todos os módulos/provas/trabalhos, previstas no curso;</h5>
                <h5>4) Manter informada a ccordenação do curso quando houver qualquer impedimento;</h5>
                <h5>5) Estar ciente de em caso de desistência, abandono do evento ou eliminação por faltas, a empresa ficará impedida por 01 (um) ano de fazer qualquer programa futuro da ação de capacitaçao técnica do software Papercut MF ministrado pela EcoprintQ Brasil</h5>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
            </div>
        </div>

    </div>
</div>
<!-- /. WRAPPER  -->
<!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
<!-- JQUERY SCRIPTS -->
<script src="assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- CUSTOM SCRIPTS -->
<script src="assets/js/custom.js"></script>



<!-- RECAPTCHA EM PT-BR-->
<script type="text/javascript">

    var widId = "";
    var onloadCallback = function ()
    {
        widId = grecaptcha.render('recapchaWidget', {
            'sitekey':'Your Site Key'
        });
    };
</script>

<script src="https://www.google.com/recaptcha/api.js"></script>
<script type="text/javascript">
    $("#btnConfirmarInscricao").click(function(){
        var res = grecaptcha.getResponse(widId);
        if (res == "" || res == undefined || res.length == 0)
        {
            return false;
        }
        return true;

    })


</script>

</body>
</html>
